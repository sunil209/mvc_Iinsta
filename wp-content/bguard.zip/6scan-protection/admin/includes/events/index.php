<?php
	print( "What? Where?! Panic!" );
?>
